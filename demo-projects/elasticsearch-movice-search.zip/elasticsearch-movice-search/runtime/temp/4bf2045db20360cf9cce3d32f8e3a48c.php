<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:90:"/www/elasticsearch-movice-search/public/../application/frontend/view/movie/movie_list.html";i:1522140246;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>movie list</title>
    <link rel="stylesheet" href="/static/css/base.css">
    <link rel="stylesheet" href="/static/css/movie-list.css">
    <script src="/static/js/jquery.js"></script>
</head>
<body>
<div class="header">
    <div class="w">
        <div class="search clearfix">
            <input type="text" class="text fl">
            <button type="button" class="search-button cursor fl">搜索</button>
        </div>
        <div class="type-filter">
            <div class="selector-line clearfix">
                <div class="sl-key fl">地区：</div>
                <div class="sl-value fl">
                    <ul>
                        <li><a href="javascript:;">全部</a></li>
                        <li><a href="javascript:;">港澳</a></li>
                        <li><a href="javascript:;">大陆</a></li>
                        <li><a href="javascript:;">国外</a></li>
                    </ul>
                </div>
            </div>
            <div class="selector-line clearfix">
                <div class="sl-key fl">语言：</div>
                <div class="sl-value fl">
                    <ul>
                        <li><a href="javascript:;">全部</a></li>
                        <li><a href="javascript:;">华语</a></li>
                        <li><a href="javascript:;">外语</a></li>
                    </ul>
                </div>
            </div>
            <div class="selector-line clearfix">
                <div class="sl-key fl">其它：</div>
                <div class="sl-value">
                    <div class="orderby-filter">
                        <ul>
                            <li><a href="javascript:;"><span>评分</span><i class="up-arrows"></i></a></li>
                            <li><a href="javascript:;"><span>上映年代</span><i class="down-arrows"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="movie-list clearfix">
    <div class="w">
        <ul class="list-row clearfix">

            <?php if(empty($data['_source'])): if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
            <li>
                <a href="javascript:;">
                    <img src="<?php echo $item['_source']['img']; ?>">
                    <span class="title"><?php echo $item['_source']['title']; ?></span>
                    <p class="score"><?php echo $item['_source']['score']; ?>分</p>
                </a>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; endif; ?>
        </ul>
        <!--分页开始-->
        <div class="pagination">
            <ul>
                <li><a href="javascript:;" class="selected">1</a></li>
                <li><a href="javascript:;">2</a></li>
                <li><a href="javascript:;">3</a></li>
                <li class="no-border"><span>...</span></li>
                <li><a href="javascript:;">100</a></li>
            </ul>
        </div>
    </div>
</div>
</body>
</html>
<script>
    var searchUrl = 'search';
</script>
<script src="/static/js/search.js"></script>