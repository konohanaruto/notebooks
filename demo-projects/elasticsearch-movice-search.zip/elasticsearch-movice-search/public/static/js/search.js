/**
 * Created by konohanaruto on 2018/3/27.
 * Blog: http://www.muyesanren.com
 * QQ: 1039814413
 * Wechat Number: wikitest
 */

$(function () {
    $('.search-button').on('click', function () {
        var keyword = $('.search .text').val();

        $.ajax({
            type: "post",
            url: searchUrl,
            data: {keyword: keyword},
            success: function (data) {
                if (data) {
                    var listRow = $('.list-row');
                    var data = JSON.parse(data);
                    listRow.html('');

                    for (var i in data) {
                        //console.log(data[i]['_source']['img']);
                        listRow.append('<li><a href="javascript:;"><img src="'+data[i]['_source']['img']+'"><span class="title">'+data[i]['highlight']['title'][0]+'</span><p class="score">'+data[i]['_source']['score']+'分</p></a></li>');
                    }
                }
            }
        });
    });
});