<?php
/**
 * Created by PhpStorm.
 * User: konohanaruto
 * Blog: http://www.muyesanren.com
 * QQ: 1039814413
 * Wechat Number: wikitest
 * Date: 2018/3/26
 * Time: 2:22
 */

namespace app\frontend\controller;

use app\frontend\model\Movies as MovieModel;
use Elasticsearch\ClientBuilder;

class Movie extends \think\Controller
{
    public $elasticSearchClient;

    public function __construct()
    {
        $hosts = ['192.168.2.111:9200'];
        $this->elasticSearchClient = ClientBuilder::create()->setHosts($hosts)->build();

        parent::__construct();
    }

    public function movieList()
    {
        $params = [
            'index' => 'movies',
            'type' => 'data',
            'from' => 0,
            'size' => 20
        ];
        $response = $this->elasticSearchClient->search($params);
//        echo '<pre>';
//        var_dump($response);exit;

        return $this->fetch('movie_list', ['data'=>$response['hits']['hits']]);
        //return view('movie_list', ['data'=>$response['hits']['hits']]);
    }

    //public function keywordSearch($keyword = null)
    public function keywordSearch()
    {
        $keyword = '火影忍者';
        $params = [
            'index' => 'movies',
            'type' => 'data',
            'body' => [
                'query' => [
                    'match' => [
                        'title' => $keyword
                    ]
                ],
                'highlight' => [
                    'pre_tags' => ['<strong style="color: red">'],
                    'post_tags' => ['</strong>'],
                    'fields' => [
                        'title' => new \stdClass()
                    ]
                ]
            ],
            'from' => 0,
            'size' => 20
        ];

        // 默认只取出十条数据
        $response = $this->elasticSearchClient->search($params);

        return json_encode($response['hits']['hits']);
        echo '<pre>';
        var_dump($response);
    }
}