<?php
/**
 * Created by PhpStorm.
 * User: konohanaruto
 * Blog: http://www.muyesanren.com
 * QQ: 1039814413
 * Wechat Number: wikitest
 * Date: 2018/3/26
 * Time: 3:15
 */

namespace app\frontend\model;

use think\Model;

class Movies extends Model
{
    protected $pk = 'id';
    protected $table = 'movies';
}